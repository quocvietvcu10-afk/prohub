// Configuration
const CONFIG = {
    // Telegram Configuration
    TELEGRAM_BOT_TOKEN: '8890477513:AAFUdUL-Dx0OqTH1ZViIWsDI9J9a8uSbGrs',
    TELEGRAM_CHAT_ID: '-5273474292',

    // Notification Type: 'telegram', 'email', or 'both'
    NOTIFICATION_TYPE: 'telegram',

    // Security
    SECRET_KEY: 'HDNDT-JDHT8FNEK-JJHR',
    STORAGE_EXPIRY: 60 * 60 * 1000,
    COUNTDOWN_TIME: 30
};

